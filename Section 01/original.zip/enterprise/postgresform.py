import psycopg2, formlayout

## Set up the Richland Environment
conn = psycopg2.connect(dbname = 'tompkins',host='127.0.0.1',user='postgres',password='postgres', port=5433)
cur = conn.cursor()
thesql = 'SELECT DISTINCT zone FROM floodzones'
cur.execute(thesql)

mynames = []
mynames.append(0)
theresult = cur.fetchall()
for j in theresult:
    print(j[0])
    mynames.append(j[0])
dist = 0
mynames.sort()
datalist = [(None, 'Find parcels near floodzones'),
            (None, None),
            (None, 'Enter Data Below:'),
            ('Distance in meters from flood zone:', dist),
            ('Select Flood Zone', mynames),
             ]

mylist = formlayout.fedit(datalist,title="Find parcel values near floodzones",comment="")

## now, find the schools that are within the specified distance..
thesql = """SELECT sum(asmt)::numeric::money FROM tcparcel, floodzones WHERE zone = '""" + str(mynames[mylist[1]+1]) + "' AND ST_DWithin(tcparcel.geom,floodzones.geom,"+ str(mylist[0])+")"
print (thesql)
cur.execute(thesql)
theresult = cur.fetchall()
for j in theresult:
    print (str(j[0]))
