SELECT tcparcel.*
FROM tcparcel, schooldistricts
WHERE st_contains(st_transform(schooldistricts.geom,32618),tcparcel.geom)
AND schooldistricts.name = 'LANSING CENTRAL SCHOOL DISTRICT'
----------------------------

SELECT tcparcel.*
FROM tcparcel, watersheds
WHERE st_contains(st_transform(watersheds.geom,32618),tcparcel.geom)
AND watersheds.watershed = 'Fall Creek'

-------------------------------------------

SELECT tcparcel.*
FROM tcparcel, floodzones
WHERE st_intersects(tcparcel.geom,floodzones.geom)
AND floodzones.zone = 'AE'


--------------------------

SELECT min(st_distance(tcparcel.geom,floodzones.geom)) as dist
FROM tcparcel, floodzones
WHERE tcparcel.parcelkey = '50308907200000010011090000'
and floodzones.zone = 'AE'

----------------------------

SELECT a.geom, a.loc || ' ' || a.location as addr
FROM tcparcel AS a, tcparcel AS b
WHERE st_touches(a.geom,b.geom)
AND b.parcelkey = '50308907200000010011090000'

----------------------------

SELECT st_buffer(geom, 100) as geom, a.loc || ' ' || a.location as addr
FROM tcparcel AS a
WHERE a.parcelkey = '50308907200000010011090000'

--------------------------------

SELECT  a.geom, a.loc || ' ' || a.location as addr
FROM tcparcel AS a, tcparcel AS b
WHERE b.parcelkey = '50308907200000010011090000'
AND st_dwithin(a.geom,b.geom,200)


CREATE TEMP TABLE watershedutm AS 
SELECT *, ST_Transform(geom,32618) AS g
FROM watersheds;

SELECT st_intersection(tcparcel.geom, floodzones.geom) as g, tcparcel.*, floodzones.zone
FROM tcparcel, floodzones 
WHERE floodzones.zone = 'AE'
AND st_intersects(tcparcel.geom,floodzones.geom)

--------------------------------


















========================================================