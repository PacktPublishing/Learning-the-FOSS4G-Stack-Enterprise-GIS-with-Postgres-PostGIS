-- CREATE OUR ROLES
CREATE ROLE assessor;
CREATE ROLE planner;
CREATE ROLE viewer;

-- CREATE OUR USERS
CREATE USER shemp WITH
	LOGIN
	NOSUPERUSER
	NOCREATEDB
	NOCREATEROLE
	INHERIT
	NOREPLICATION
	CONNECTION LIMIT -1
	PASSWORD 'shemp';
GRANT viewer TO shemp;

CREATE USER mo WITH
	PASSWORD 'mo';

CREATE USER larry WITH
	PASSWORD 'larry';
	
CREATE USER curly WITH
	PASSWORD 'curly';

--
-- SHOW THE GRANT WIZARD - HONESTLY, IT'S A LITTLE CUMBERSOME
--

-- START GRANTING PERMISSIONS WITH SQL
GRANT SELECT ON TABLE public.floodzones TO viewer WITH GRANT OPTION;
GRANT SELECT ON TABLE public.firestations TO viewer WITH GRANT OPTION;
GRANT viewer to assessor;
GRANT viewer to larry;
GRANT assessor TO mo;
GRANT assessor, planner, viewer TO larry;

--UGH, THAT'S GOING TO TAKE A WHILE
GRANT SELECT ON ALL TABLES IN SCHEMA public TO viewer;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO assessor;

-- ENABLE EDITING ON SELECT TABLES, CHECK AS WE GO
GRANT UPDATE ON tcparcel TO assessor;

GRANT DELETE ON tcparcel TO assessor;

-- NOW LOOK HOW WE CAN MORE THINGS TO THE ASSESSOR
GRANT DELETE ON tcparcel TO assessor;
GRANT INSERT ON tcparcel TO assessor;
REVOKE INSERT, DELETE ON tcparcel FROM assessor;
GRANT INSERT, UPDATE, DELETE ON tcparcel TO assessor;

-- DO IT IN ONE SHOT
GRANT INSERT, UPDATE, DELETE ON tcparcel, firestations TO assessor, curly;

-- NOTICE WE CAN'T ADD A FEATURE.  LET'S ADD A SEQUENCE
GRANT USAGE, SELECT ON SEQUENCE  tcparcel_id_seq TO assessor;

--
--  TRIGGERS AND CONSTRAINTS
--
-- CONSTRAINT ON school districts

ALTER TABLE tcparcel
ADD CONSTRAINT schdist_constraint CHECK (schdist in ('Spencer-Van Etten',
'Ithaca City',
'Newfield',
'Southern Cayuga',
'Cortland Csd',
'Candor',
'Newark Valley',
'Homer',
'Moravia',
'Dryden',
'George Jr',
'Odessa-Montour',
'Groton',
'Lansing',
'Trumansburg'))

ALTER TABLE tcparcel
ADD CONSTRAINT asmtval CHECK (asmt > 0)
NOT VALID
													 
-- ALTER the table to create a land value

ALTER TABLE tcparcel ADD COLUMN structval float;

-- TRIGGERS
-- On an update, let's calculate the structure value


CREATE OR REPLACE FUNCTION tompkins.public.update_parcels() 
RETURNS trigger AS $update_parcels$ 
    BEGIN        
        NEW.structval = new.asmt - new.land;
    RETURN NEW; 
    END;
$update_parcels$ LANGUAGE 'plpgsql';
 
CREATE TRIGGER update_parcels BEFORE INSERT OR UPDATE ON tompkins.public.tcparcel 
	FOR EACH ROW EXECUTE PROCEDURE tompkins.public.update_parcels();

--
-- Let's add a spatial trigger
-- Make sure parcels are in a watershed, and
-- give the watershed value name to the parcel

ALTER TABLE tcparcel ADD COLUMN structval float; 
ALTER TABLE tcparcel ADD COLUMN watershed varchar;

CREATE OR REPLACE FUNCTION tompkins.public.update_parcels() 
RETURNS trigger AS $update_parcels$
DECLARE thewatershed varchar;
	BEGIN 
--Check for the property class 
		IF NEW.propclass IS NULL THEN 
			RAISE EXCEPTION 'error: propclass field cannot be empty'; 
		END IF;
--DROP TRIGGER IF EXISTS update_parcels ON tompkins.public.tcparcel;

CREATE OR REPLACE TRIGGER update_parcels BEFORE INSERT OR UPDATE ON tompkins.public.tcparcel 
	FOR EACH ROW EXECUTE PROCEDURE tompkins.public.update_parcels(); 		
-- Retrieve the name of the watershed
		thewatershed = (SELECT watershed as watershed 
						 FROM watersheds 
						 WHERE ST_Within(ST_Centroid(NEW.geom), ST_TRANSFORM(watersheds.geom,32618)) LIMIT 1); 			 	
		IF thewatershed IS NULL THEN 
			RAISE EXCEPTION 'error: parcels must be in a watershed'; 
		END IF; 
	-- Get ready to add the record
		NEW.watershed = thewatershed;
		RETURN NEW; 
		END; 
		$update_parcels$ LANGUAGE plpgsql; 
										 
--
-- CLEAN UP
--
--
CREATE OR REPLACE FUNCTION tompkins.public.update_parcels() 
RETURNS trigger AS $update_parcels$	
DECLARE thewatershed varchar;										 
	BEGIN 
-- Retrieve the name of the watershed
		thewatershed = (SELECT watershed as watershed 
						 FROM watersheds 
						 WHERE ST_Within(ST_Centroid(NEW.geom), ST_TRANSFORM(watersheds.geom,32618)) LIMIT 1); 			 	
		IF thewatershed IS NULL THEN 
			RAISE EXCEPTION 'error: parcels must be in a watershed'; 
		
	-- Get ready to add the record
		ELSE								 
			NEW.watershed = thewatershed;
			RETURN NEW; 
		END IF; 
	END; 
	$update_parcels$ LANGUAGE plpgsql; 	
										 
GRANT EXECUTE ON FUNCTION update_parcels() TO assessor;
										 
CREATE TRIGGER update_parcels BEFORE INSERT OR UPDATE ON tompkins.public.tcparcel 
	FOR EACH ROW EXECUTE PROCEDURE tompkins.public.update_parcels();										 