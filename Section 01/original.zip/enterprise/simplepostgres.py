import psycopg2

## Set up environment
conn = psycopg2.connect(dbname = 'tompkins',host='127.0.0.1',user='larry',password='larry', port=5433)
cur = conn.cursor()
fzone = 'AE'
thedist = 100
##fzone = raw_input('Enter the floodzone you want to check: ')
##thedist = raw_input('Enter the distance you want to search: ')

## now, find the parcels that are within the specified distance..
thesql = """SELECT sum(asmt)::numeric::money
            FROM tcparcel, floodzones
            WHERE zone = '""" + str(fzone) + """'
            AND ST_DWithin(tcparcel.geom,floodzones.geom,""" +str(thedist)+")"
print (thesql)
cur.execute(thesql)
theresult = cur.fetchall()
for j in theresult:
    print (str(j[0]))
